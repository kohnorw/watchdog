import requests, re, base64
from database import get_setting

def sonarr_headers():
    return {'X-Api-Key': get_setting('sonarr_api_key'), 'Content-Type': 'application/json'}

def radarr_headers():
    return {'X-Api-Key': get_setting('radarr_api_key'), 'Content-Type': 'application/json'}

def rd_headers():
    return {'Authorization': f"Bearer {get_setting('rd_api_key')}"}

def decypharr_auth():
    u = get_setting('decypharr_user', 'admin')
    p = get_setting('decypharr_pass', 'admin')
    return base64.b64encode(f"{u}:{p}".encode()).decode()

def get_sonarr_shows():
    url = f"{get_setting('sonarr_url').rstrip('/')}/api/v3/series"
    r = requests.get(url, headers=sonarr_headers(), timeout=10); r.raise_for_status(); return r.json()

def add_sonarr_show(tvdb_id, title, year, quality_profile_id=None, root_folder=None):
    url = f"{get_setting('sonarr_url').rstrip('/')}/api/v3/series"
    payload = {'title': title, 'year': int(year or 0), 'tvdbId': int(tvdb_id),
        'qualityProfileId': quality_profile_id or int(get_setting('sonarr_quality_profile', 1)),
        'rootFolderPath': root_folder or get_setting('sonarr_root_folder', '/tv/'),
        'monitored': True, 'addOptions': {'searchForMissingEpisodes': True}}
    r = requests.post(url, headers=sonarr_headers(), json=payload, timeout=10); r.raise_for_status(); return r.json()

def get_sonarr_quality_profiles():
    url = f"{get_setting('sonarr_url').rstrip('/')}/api/v3/qualityprofile"
    r = requests.get(url, headers=sonarr_headers(), timeout=10); r.raise_for_status(); return r.json()

def get_sonarr_root_folders():
    url = f"{get_setting('sonarr_url').rstrip('/')}/api/v3/rootfolder"
    r = requests.get(url, headers=sonarr_headers(), timeout=10); r.raise_for_status(); return r.json()

def get_radarr_movies():
    url = f"{get_setting('radarr_url').rstrip('/')}/api/v3/movie"
    r = requests.get(url, headers=radarr_headers(), timeout=10); r.raise_for_status(); return r.json()

def add_radarr_movie(tmdb_id, title, year, quality_profile_id=None, root_folder=None):
    url = f"{get_setting('radarr_url').rstrip('/')}/api/v3/movie"
    payload = {'title': title, 'year': int(year or 0), 'tmdbId': int(tmdb_id),
        'qualityProfileId': quality_profile_id or int(get_setting('radarr_quality_profile', 1)),
        'rootFolderPath': root_folder or get_setting('radarr_root_folder', '/movies/'),
        'monitored': True, 'addOptions': {'searchForMovie': True}}
    r = requests.post(url, headers=radarr_headers(), json=payload, timeout=10); r.raise_for_status(); return r.json()

def get_radarr_quality_profiles():
    url = f"{get_setting('radarr_url').rstrip('/')}/api/v3/qualityprofile"
    r = requests.get(url, headers=radarr_headers(), timeout=10); r.raise_for_status(); return r.json()

def get_radarr_root_folders():
    url = f"{get_setting('radarr_url').rstrip('/')}/api/v3/rootfolder"
    r = requests.get(url, headers=radarr_headers(), timeout=10); r.raise_for_status(); return r.json()

def get_rd_torrents(page=1, limit=100):
    r = requests.get('https://api.real-debrid.com/rest/1.0/torrents',
        headers=rd_headers(), params={'page': page, 'limit': limit}, timeout=15)
    r.raise_for_status(); return r.json()

def delete_rd_torrent(torrent_id):
    r = requests.delete(f'https://api.real-debrid.com/rest/1.0/torrents/delete/{torrent_id}',
        headers=rd_headers(), timeout=10)
    return r.status_code in (200, 204)

def add_rd_magnet(magnet):
    r = requests.post('https://api.real-debrid.com/rest/1.0/torrents/addMagnet',
        headers=rd_headers(), data={'magnet': magnet}, timeout=10)
    r.raise_for_status(); return r.json()

def select_rd_files(torrent_id, files='all'):
    r = requests.post(f'https://api.real-debrid.com/rest/1.0/torrents/selectFiles/{torrent_id}',
        headers=rd_headers(), data={'files': files}, timeout=10)
    return r.status_code in (200, 204)

def add_to_decypharr(magnet, category='sonarr'):
    url = get_setting('decypharr_url', '').rstrip('/')
    r = requests.post(f'{url}/api/v2/torrents/add',
        headers={'Authorization': f'Basic {decypharr_auth()}'},
        data={'urls': magnet, 'category': category}, timeout=10)
    return r.status_code == 200

def reinsert_via_decypharr(torrent_id, torrent_hash, category):
    magnet = f"magnet:?xt=urn:btih:{torrent_hash}"
    delete_rd_torrent(torrent_id)
    result = add_rd_magnet(magnet)
    new_id = result.get('id')
    if new_id:
        select_rd_files(new_id)
    add_to_decypharr(magnet, category)
    return new_id

def search_tmdb_movie(title, year=None):
    key = get_setting('tmdb_api_key')
    params = {'api_key': key, 'query': title}
    if year: params['year'] = year
    r = requests.get('https://api.themoviedb.org/3/search/movie', params=params, timeout=10)
    r.raise_for_status()
    results = r.json().get('results', [])
    return results[0] if results else None

def search_tvdb_show(title):
    url = f"{get_setting('sonarr_url').rstrip('/')}/api/v3/series/lookup"
    r = requests.get(url, headers=sonarr_headers(), params={'term': title}, timeout=10)
    r.raise_for_status()
    results = r.json()
    return results[0] if results else None

def parse_filename(filename):
    tv = re.search(r'[Ss](\d{1,2})[Ee](\d{1,2})', filename)
    if tv:
        title_part = filename[:tv.start()]
        title = re.sub(r'[\.\-\_]', ' ', title_part).strip()
        title = re.sub(r'\s+', ' ', title).strip()
        yr = re.search(r'\b(19|20)\d{2}\b', title)
        year = int(yr.group()) if yr else None
        if yr: title = title[:yr.start()].strip()
        return {'type': 'show', 'title': title, 'year': year}
    name = re.sub(r'\.(mkv|mp4|avi|ts)$', '', filename, flags=re.IGNORECASE)
    name = re.sub(r'\[.*?\]', '', name)
    yr = re.search(r'\b(19|20)\d{2}\b', name)
    year = int(yr.group()) if yr else None
    title_part = name[:yr.start()] if yr else name
    title = re.sub(r'[\.\-\_]', ' ', title_part).strip()
    title = re.sub(r'\s+', ' ', title).strip()
    title = re.sub(r'\b(1080p|720p|4K|2160p|BluRay|WEB|HDTV|x264|x265|HEVC|AAC|DTS|HDR)\b.*', '', title, flags=re.IGNORECASE).strip()
    return {'type': 'movie', 'title': title, 'year': year}
