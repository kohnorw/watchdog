import re
from thefuzz import fuzz
from database import get_db
from api_clients import (get_sonarr_shows, get_radarr_movies, get_rd_torrents,
    reinsert_via_decypharr, search_tmdb_movie, search_tvdb_show,
    add_sonarr_show, add_radarr_movie, parse_filename)

MATCH_THRESHOLD = 80

def normalize(t):
    return re.sub(r'\s+', ' ', re.sub(r'[^\w\s]', ' ', t.lower())).strip()

def fuzzy_match(title, items):
    best_score, best_item = 0, None
    norm = normalize(title)
    for item in items:
        score = fuzz.token_sort_ratio(norm, normalize(item['title']))
        if score > best_score:
            best_score, best_item = score, item
    return best_item, best_score

def sync_sonarr_radarr():
    conn = get_db()
    try:
        shows = get_sonarr_shows()
        conn.execute('DELETE FROM sonarr_shows')
        for s in shows:
            conn.execute('INSERT OR REPLACE INTO sonarr_shows (id,tvdb_id,title,year,status) VALUES (?,?,?,?,?)',
                (s['id'],s.get('tvdbId'),s['title'],s.get('year'),s.get('status','')))
        movies = get_radarr_movies()
        conn.execute('DELETE FROM radarr_movies')
        for m in movies:
            conn.execute('INSERT OR REPLACE INTO radarr_movies (id,tmdb_id,title,year,status) VALUES (?,?,?,?,?)',
                (m['id'],m.get('tmdbId'),m['title'],m.get('year'),m.get('status','')))
        conn.commit()
        return len(shows), len(movies)
    finally:
        conn.close()

def process_rd_page(page=1, full_sync=False):
    conn = get_db()
    matched = unmatched = 0
    errors = []
    try:
        shows = [dict(r) for r in conn.execute('SELECT * FROM sonarr_shows').fetchall()]
        movies = [dict(r) for r in conn.execute('SELECT * FROM radarr_movies').fetchall()]
        torrents = get_rd_torrents(page=page, limit=100)
        for torrent in torrents:
            tid = torrent['id']
            filename = torrent.get('filename','')
            thash = torrent.get('hash','')
            existing = conn.execute('SELECT processed FROM rd_torrents WHERE id=?',(tid,)).fetchone()
            if existing and existing['processed']:
                continue
            conn.execute('INSERT OR REPLACE INTO rd_torrents (id,filename,hash,status,bytes,added) VALUES (?,?,?,?,?,?)',
                (tid,filename,thash,torrent.get('status',''),torrent.get('bytes',0),torrent.get('added','')))
            parsed = parse_filename(filename)
            content_type, title, year = parsed['type'], parsed['title'], parsed['year']
            if not title:
                unmatched += 1
                conn.execute('INSERT OR IGNORE INTO unmatched (rd_torrent_id,filename,suggested_type) VALUES (?,?,?)',(tid,filename,content_type))
                continue
            if content_type == 'show':
                item, score = fuzzy_match(title, shows)
                if score >= MATCH_THRESHOLD and item:
                    conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?',('show',item['id'],item['title'],tid))
                    try: reinsert_via_decypharr(tid,thash,'sonarr')
                    except Exception as e: errors.append(f"Reinsert {filename}: {e}")
                    matched += 1
                else:
                    try:
                        result = search_tvdb_show(title)
                        if not result: raise Exception('No TVDB result')
                        new = add_sonarr_show(result.get('tvdbId'),result.get('title',title),result.get('year',year or 0))
                        conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?',('show',new.get('id'),new.get('title'),tid))
                        reinsert_via_decypharr(tid,thash,'sonarr')
                        matched += 1
                    except Exception as e:
                        errors.append(f"{filename}: {e}"); unmatched += 1
                        conn.execute('INSERT OR IGNORE INTO unmatched (rd_torrent_id,filename,suggested_title,suggested_type) VALUES (?,?,?,?)',(tid,filename,title,'show'))
            else:
                item, score = fuzzy_match(title, movies)
                if score >= MATCH_THRESHOLD and item:
                    conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?',('movie',item['id'],item['title'],tid))
                    try: reinsert_via_decypharr(tid,thash,'radarr')
                    except Exception as e: errors.append(f"Reinsert {filename}: {e}")
                    matched += 1
                else:
                    try:
                        result = search_tmdb_movie(title,year)
                        if not result: raise Exception('No TMDB result')
                        yr = result.get('release_date','')[:4] or year or 0
                        new = add_radarr_movie(result['id'],result['title'],yr)
                        conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?',('movie',new.get('id'),new.get('title'),tid))
                        reinsert_via_decypharr(tid,thash,'radarr')
                        matched += 1
                    except Exception as e:
                        errors.append(f"{filename}: {e}"); unmatched += 1
                        conn.execute('INSERT OR IGNORE INTO unmatched (rd_torrent_id,filename,suggested_title,suggested_type) VALUES (?,?,?,?)',(tid,filename,title,'movie'))
        conn.execute('INSERT INTO run_log (torrents_processed,matched,unmatched,errors) VALUES (?,?,?,?)',
            (len(torrents),matched,unmatched,'\n'.join(errors)))
        conn.commit()
    finally:
        conn.close()
    return {'matched': matched, 'unmatched': unmatched, 'errors': errors}
