#!/bin/bash
set -e
echo "Building Watchdog..."
docker stop watchdog 2>/dev/null || true
docker rm watchdog 2>/dev/null || true
docker rmi watchdog 2>/dev/null || true
mkdir -p /docker/watchdog/data /docker/watchdog/templates
docker build --no-cache -t watchdog .
docker run -d \
  --name watchdog \
  --restart unless-stopped \
  -p 5001:5000 \
  -v /docker/watchdog/data:/data \
  -v /docker/sonarr/plex/shows:/tv \
  -v /docker/zurg/mnt/zurg/shows:/docker/zurg/mnt/zurg/shows:ro \
  watchdog
echo "Done: http://$(hostname -I | awk '{print $1}'):5001"
